Multi-Agent Restaurant Rater (AI Homework #3)
This project implements a multi-agent system for rating restaurants based on textual reviews, using the AutoGen framework and large language models (LLMs).

Author
Name: 王獻霆
Student ID: r13945041
Course: Artificial Intelligence, NTU, Spring 2025

1. Environment Setup
Requirements:
Python 3.8 
pyautogen version 0.9.0

Model requirements:
OpenAI GPT-4o-mini model (you need your own API key)

2. API Key Setup
To use the OpenAI API, set your API key as an environment variable:
export OPENAI_API_KEY=your-api-key-here
Important: Never hardcode your API key in the code or share it publicly.

3. Usage
Public test: python test.py
The execution result will be directly output to the terminal.

4. Note on Result Consistency:
The output may vary between runs even with the same input. This is a common phenomenon in LLM-based systems (e.g., GPT-4o-mini) due to model randomness and prompt sensitivity. Sometimes, small variations in the model's output or JSON formatting may occur.
To ensure reliability, I have tested this program many times. The fact that all public cases passed in this particular run is partly due to luck, as occasional random errors or format mismatches may still occur.
In practice, it is rare for all cases to pass on every single run without some minor fluctuation.