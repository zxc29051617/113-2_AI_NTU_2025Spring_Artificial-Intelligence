
# 🚀 User Guide

## 1. Environment Requirements

### 1.1 Python Packages

Please ensure the following packages are installed in your Colab or local virtual environment:

```bash
pip install -U langchain-community transformers sentence-transformers torch chromadb pypdf pymupdf Pillow pdf2image poppler-utils kaggle flash_attn==2.7.4.post1 accelerate==1.3.0 soundfile==0.13.1 scipy==1.15.2 torchvision==0.21.0 backoff==2.2.1 peft==0.13.2 faiss-cpu
```

> **Notes**  
> - `langchain-community`: Latest Chroma vector database and PDF loader  
> - `chromadb`: Build and search document vector databases  
> - `transformers`, `torch`: Load HuggingFace pre-trained models (Phi-2 / Phi-4)  
> - `sentence-transformers`: Sentence embeddings (vectorization)  
> - `pypdf`, `pymupdf`: PDF document parsing and page handling  
> - `pdf2image` + `poppler-utils`: Convert PDF pages to images for Phi-4 processing  
> - `flash_attn`, `accelerate`, `peft`: Speed up large model inference  
> - `faiss-cpu`: Build efficient vector search indexes  
> - `kaggle`: Download competition files

---

### 1.2 Google Colab Settings

- Open Colab
- Select "Runtime" → "Change runtime type" → **Set GPU** as the hardware accelerator
- **Recommended GPU: A100**, especially for Phi-4 multimodal models due to large VRAM requirements.

---

## 2. Execution Steps

### 2.1 Mount Google Drive

Place the following files under your Google Drive folder `/MyDrive/AI_hw2/`:
- `resume.pdf`
- `AI.pdf`
- `HW2_query.csv`
- `kaggle.json` (Kaggle API key)

Mount the drive:

```python
from google.colab import drive
drive.mount('/content/drive')
```

---

### 2.2 Task 1: RAG on Resume

1. Confirm the settings in `task1.py`:
   ```python
   CV_FILE = "/content/drive/MyDrive/AI_hw2/resume.pdf"
   LLM_MODEL = "microsoft/phi-2"
   EMBEDDINGS = "sentence-transformers/all-MiniLM-L6-v2"
   ```
2. Run:
   ```bash
   python task1.py
   ```
3. You will see output results:
   - 🧪 Response using only LLM (baseline)
   - 🧠 Response using RAG with Resume as context

---

### 2.3 Task 2: Page Retrieval with Phi-4 Captioning

#### 2.3.1 Download Kaggle Competition Files

```bash
!mkdir ~/.kaggle
!cp kaggle.json ~/.kaggle/
!chmod 600 ~/.kaggle/kaggle.json
!kaggle competitions download -c ntu-artificial-intelligence-2025-hw-2
!unzip ntu-artificial-intelligence-2025-hw-2.zip
```

---

#### 2.3.2 Generate Captions for Each PDF Page

Run:

```bash
python phi4_caption.py
```

Output format:

```json
[
  {"page_number": 1, "caption": "This page describes CNN structure..."},
  {"page_number": 2, "caption": "Flowchart for dataset preparation..."},
  ...
]
```

---

#### 2.3.3 Build FAISS Vector Search Index

```python
index, caption_list = build_caption_index(captions, model)
```

---

#### 2.3.4 Perform Query Retrieval and Save Results

```python
queries = load_queries("HW2_query.csv")

for query in queries:
    best_match = retrieve_best_page(query["question"], index, caption_list, model, top_k=5)
    results.append({"id": query["id"], "page_number": best_match["page_number"]})

save_answers_to_csv(results, "HW2_answer.csv")
```

The final output will be `HW2_answer.csv`, ready for Kaggle submission.

---

## 3. Notes

- **Restart the Colab Runtime** after installing new packages to ensure proper environment refresh.
- **Phi-4 model** requires A100 or equivalent large GPU. Colab Free version might not be sufficient.
- To rebuild vector stores, simply delete folders `cv_db/` and `ai_vector_db/` and rerun the scripts.

---
